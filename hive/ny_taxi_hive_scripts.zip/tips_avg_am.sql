CREATE EXTERNAL TABLE tips_avg_am (
`Payment type` STRING,
`Date` string,
`Tips average amount` DOUBLE,
`Passenger total` INT
)
COMMENT 'This is the tips average amount data mart';
