CREATE DATABASE yellow_taxi location 's3a://newtaxibacket/nytaxidata';

