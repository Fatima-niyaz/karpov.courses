INSERT INTO tips_avg_am
select * FROM tips_avg_am_vw;